package com.example.demo.Domain.Common.Repository;

import com.example.demo.Domain.Common.Entity.Book;
import com.example.demo.Domain.Common.Entity.Lend;
import com.example.demo.Domain.Common.Entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LendRepositoryTest {

    @Autowired
    private LendRepository lendRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private BookRepository bookRepository;

    @Test
    public void t1(){
        //SELECT ALL
//        List<Lend> list=lendRepository.findAll();
//        list.forEach(System.out::println);

        //INSERT
        User user=userRepository.findById("user1").get();
        Book book=bookRepository.findById(1L).get();

        Lend lend=Lend.builder()
                .id(null)
                .user(user)
                .book(book)
                .build();
        lendRepository.save(lend);
    }

    @Test
    public void t2(){
        //user1 bookCode 1L 대여
//        User user=userRepository.findById("user1").get();
//        Book book=bookRepository.findById(1L).get();

//        Lend lend=Lend.builder()
//                .id(null)
//                .user(user)
//                .book(book)
//                .build();
//        lendRepository.save(lend);

        //user1 bookCode 2L 대여
//        User user=userRepository.findById("user1").get();
//        Book book=bookRepository.findById(2L).get();
//        Lend lend=Lend.builder()
//                .id(null)
//                .user(user)
//                .book(book)
//                .build();
//        lendRepository.save(lend);

        //user2 bookCode 3L 대여
//        User user=userRepository.findById("user2").get();
//        Book book=bookRepository.findById(3L).get();
//        Lend lend=Lend.builder()
//                .id(null)
//                .user(user)
//                .book(book)
//                .build();
//        lendRepository.save(lend);

        //user3 bookCode 4L 대여
        User user=userRepository.findById("user3").get();
        Book book=bookRepository.findById(4L).get();
        Lend lend=Lend.builder()
                .id(null)
                .user(user)
                .book(book)
                .build();
        lendRepository.save(lend);

    }
}